package com.nucleus;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Result;



@Action(value = "login", results = {
		@Result(name = "SUCCESS", location = "/welcome.jsp"),
		@Result(name = "ERROR", location = "/error.jsp") })
public class Login{

	public String execute() throws Exception {
		
		if("priya".equals(getUsername()) && "admin".equals(getPassword()))
		{
			return "SUCCESS";
		}
		else 
			{
			return "ERROR";
			}
		
	}
	
	
	private String username;
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	
	

}
